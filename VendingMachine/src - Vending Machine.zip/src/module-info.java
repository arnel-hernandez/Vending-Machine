module VendingMachine {
}